$(document).ready(function(){
	
	$(document).ready(function(){
		//스크롤 높이값
		var docH = $(document).height();
		var headH = $(".headH").outerHeight();
		var fixH = $(".fixH").outerHeight();
		var footH = $(".footH").outerHeight();
		var conH = $(".conH05").css("height",  docH - headH - footH).outerHeight(true);
		var tblH = $(".tabel_head").outerHeight() || 0;
		var tabH = $(".tab_tit").outerHeight() || 0;

		$(".conH").css("height", docH - headH).outerHeight();
		$(".conH02").css("height", docH - headH - fixH).outerHeight();
		$(".conH03").css("height", conH - fixH - tblH - tabH).outerHeight();
		$(".conH04").css("height", docH - headH - footH).outerHeight();
	});
		
	// sub menu toggle
	$(".subMenu").css("display","none");
	$(".btn_open_sub").click(function(){
		$(this).toggleClass("open");
		$(this).parents().find(".subMenu").slideToggle("fast");
	});   
	
	// tab menu
	 $(".tab_tit li").click(function() {
	    var idx = $(this).index();
	    $(".tab_tit li").removeClass("on");
	    $(".tab_tit li").eq(idx).addClass("on");
	    $(".tab_cont > div").hide();
	    $(".tab_cont > div").eq(idx).show();
	  });
		  
	// toggle
	$(".btn_open").click(function(){
		$(this).toggleClass("close");
		$(this).parents(".openWrap").find(".openCon").slideToggle("fast",function(){
			//스크롤 높이값
			var docH = $(document).height();
			var headH = $(".headH").outerHeight();
			var fixH = $(".fixH").outerHeight();
			var footH = $(".footH").outerHeight();
			var conH = $(".contents").css("height",  docH - headH - footH).outerHeight(true);
			var tblH = $(".tabel_head").outerHeight() || 0;
			var tabH = $(".tab_tit").outerHeight() || 0;

			$(".conH").css("height", docH - headH).outerHeight();
			$(".conH02").css("height", docH - headH - fixH).outerHeight();
			$(".conH03").css("height", conH - fixH - tblH - tabH).outerHeight();
			$(".conH04").css("height", docH - headH - footH).outerHeight();
		});
		
		
	});   
	
	// list progress bar
	var $bar = $(".bar");
	for(var j=0; j<$bar.length; j++) {
		var $per = $($bar[j]).data("per");
		var $pertxt = $per + "%";
		$($bar[j]).animate({width:$pertxt});
	};
		
	
});



