var page = {
  // 0. 함수 실행
  init: function (param) {
    console.log(param.data.detail);
    page.initData(param.data.detail);
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function (param) {
    page.reqList(param);


  },

  // 2. 사용자 인터렉션
  initInterface: function () {
    

  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {
   
     
  },

  reqList : function(seq){
    bizMOB.Network.requestTr({
      "_sTrcode" : "DM0003",
      "_oBody" : {
          "docId" : seq
      },
      "_fCallback" : function(res){
        console.log(res.body);
        page.renderList(res.body);

      }
  });
  console.log(seq);

  },

  renderList : function(data){
    var dir = [
      
        // 각 row를 읽어온다음 그 안의 value값을 한개씩 가져온다.
        // { "type" : "single", "target" : ".@seq", "value" : "docId" }, // @는 선택한 Element에 Property값으로 설정한다는 의미
        // .@seq에서 .의 의미는 상위 value... 즉 li에 seq라는 property가 생성된다.
        { "type" : "single", "target" : ".title", "value" : "title" },
        { "type" : "single", "target" : ".contents", "value" : "contents" },
        { "type" : "single", "target" : ".regDate", "value" : function(arg){ 
          //console.log(arg.item.regDate);
           var regDate = arg.item.regDate +"00"; //서버에서 12자리로만 인식받기 때문에 임의로 00을 붙여준다.
           return regDate.bMToFormatDate("yyyy.mm.dd HH:mm:ss");
          //  return "<span>hong hong</span>"
        }},
        { "type" : "single", "target" : ".regName", "value" : "regName" },
        { "type" : "single", "target" : ".attachFrag", "value" : "attachFlag" }

       //res.body.list 값을 계속 받아올거니까...
      // 타켓에는 html 요소, value에는 리스트의 key값을 적으면 된다.
    ];

    var options ={ clone : false, newId : "list", replace : false };

    $("#listT").bMRender(data,dir,options); //ul 밑에 append 된다. data, dir, options 3개는 필수

  }
};//page