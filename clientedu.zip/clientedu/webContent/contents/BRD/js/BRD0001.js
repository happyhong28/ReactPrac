var page = {
  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {
    page.reqList();


  },

  // 2. 사용자 인터렉션
  initInterface: function () {
    
    // initInterface가 실행되는 시점에는 
    // 동적으로 생성한 element들이 생성하기 전이라서
    // click이벤트가 먹지 않음...
    // 그래서 정적 element인 body에 click 이벤트를 걸고
    // on 함수로 나중에 생성될 요소들까지 이벤트를 걸어준다.
    $("body").on("click","li",function () {
      console.log("click");
      bizMOB.Window.open({
        "_sPagePath": "BRD/html/BRD0002.html",
        "_oMessage": {
          "detail": $(this).attr("seq") //this 는 클릭된 element의 attr를 받기 위해서...
        }
      });

    });

  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {
    util.setBackTitle("게시판");
   
     
  },

  //
  reqList : function(){
    bizMOB.Network.requestTr({
      "_sTrcode" : "DM0002",
      "_oBody" : {
          "startIndex" : 0,
          "endIndex" : 9

      },
      "_fCallback" : function(res){
        console.log(res);
        page.renderList(res.body);

      }
  });

  },

  renderList : function(data){
    var dir = [
      { "type" : "loop", "target" : "li", "value" : "list", "detail" : [ //loop라고 적어주면 알아서 순서를 읽어옴 0,1,2 ...

        // 각 row를 읽어온다음 그 안의 value값을 한개씩 가져온다.
        { "type" : "single", "target" : ".@seq", "value" : "docId" }, // @는 선택한 Element에 Property값으로 설정한다는 의미
        // .@seq에서 .의 의미는 상위 value... 즉 li에 seq라는 property가 생성된다.
        { "type" : "single", "target" : ".title", "value" : "title" },
        { "type" : "single", "target" : ".date", "value" : function(arg){ 
          console.log(arg.item.regDate);
           var regDate = arg.item.regDate +"00"; //서버에서 12자리로만 인식받기 때문에 임의로 00을 붙여준다.
           return regDate.bMToFormatDate("yyyy.mm.dd");
          //  return "<span>hong hong</span>"
        }},
        // { "type" : "single", "target" : ".date", "value" : "regDate"},
        { "type" : "single", "target" : ".attachFrag", "value" : "attachFlag" }

      ]} //res.body.list 값을 계속 받아올거니까...
      // 타켓에는 html 요소, value에는 리스트의 key값을 적으면 된다.
    ];

    var options ={ clone : true, newId : "list", replace : false };

    $("#listT").bMRender(data,dir,options); //ul 밑에 append 된다. data, dir, options 3개는 필수

  }

}//page