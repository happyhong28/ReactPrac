var page = {
    // 0. 함수 실행
    init: function () {
        page.initData();
        page.initInterface();
        page.initLayout();
    },

    // 1. 초기 데이터 관리
    initData: function () {
        page.draw_navigation();
        page.draw_default();


    },

    // 2. 사용자 인터렉션
    initInterface: function () {


    },

    // 3. 레이아웃 타이틀바, 툴바, 사이드바
    initLayout: function () {


    },

    draw_navigation: function () {

        var swiper1 = new Swiper(".navigation", {
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
        });

    },

    draw_default: function () {
        var swiper2 = new Swiper(".default", {

            slidesPerView: 3, //슬라이드를 한번에 3개를 보여준다
            spaceBetween: 30, //슬라이드간 padding 값 30px 씩 떨어뜨려줌
            loop: true, //loop 를 true 로 할경우 무한반복 슬라이드 false 로 할경우 슬라이드의 끝에서 더보여지지 않음
        });

    }
}//page