var labels = [];
var data = [];
var line_chart;

var page = {

  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {

    page.draw_chart([], []); //초기화면 세팅



  },

  // 2. 사용자 인터렉션
  initInterface: function () {
    $.datepicker.setDefaults({
      dateFormat: 'yy-mm-dd' //Input Display Format 변경
      , showOtherMonths: true //빈 공간에 현재월의 앞뒤월의 날짜를 표시
      , showMonthAfterYear: true //년도 먼저 나오고, 뒤에 월 표시
      , changeYear: true //콤보박스에서 년 선택 가능
      , changeMonth: true //콤보박스에서 월 선택 가능                
      , showOn: "both" //button:버튼을 표시하고,버튼을 눌러야만 달력 표시 ^ both:버튼을 표시하고,버튼을 누르거나 input을 클릭하면 달력 표시  
      , buttonImage: "http://jqueryui.com/resources/demos/datepicker/images/calendar.gif" //버튼 이미지 경로
      , buttonImageOnly: true //기본 버튼의 회색 부분을 없애고, 이미지만 보이게 함
      , buttonText: "선택" //버튼에 마우스 갖다 댔을 때 표시되는 텍스트                
      , yearSuffix: "년" //달력의 년도 부분 뒤에 붙는 텍스트
      , monthNamesShort: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'] //달력의 월 부분 텍스트
      , monthNames: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'] //달력의 월 부분 Tooltip 텍스트
      , dayNamesMin: ['일', '월', '화', '수', '목', '금', '토'] //달력의 요일 부분 텍스트
      , dayNames: ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'] //달력의 요일 부분 Tooltip 텍스트
      , minDate: "0D" //최소 선택일자(-1D:하루전, -1M:한달전, -1Y:일년전)
      // ,maxDate: "+1M" //최대 선택일자(+1D:하루후, -1M:한달후, -1Y:일년후)    
    });

    $("#datepicker").datepicker();
    $('#datepicker').datepicker('setDate', 'today');


    // 제출 버튼
    $("#btn_submit").click(function () {
      if ($("#get_value").val() == "") {
        alert("값을 입력하세요~!");
      } else {



        var date = $("#datepicker").datepicker("getDate");
        var str = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate(); //yy-mm-dd 형태로 저장...

        if (labels.indexOf(str) == -1) { // 새로운 값일때...
          labels.push(str);
          data.push(parseInt($("#get_value").val()));
        } else { //이미 존재하는 값일때...
          data[labels.indexOf(str)] = parseInt($("#get_value").val());
        }
        $("#get_value").val("");
        console.log(labels);
        console.log(data);

        var color = page.getRandomColor()
        page.draw_chart(labels, data, color);
      }

    });

    // 삭제 버튼
    $("#btn_remove").click(function () {

      if (labels.length != 0) {

        labels.pop();
        data.pop();
        console.log(labels);
        console.log(data);

        var color = page.getRandomColor();
        page.draw_chart(labels, data, color);

      } else {
        alert("데이터 없음~");
      }

    });

  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {


  },

  draw_chart: function (labels, data, color) {
    // #3 line chart

    if (line_chart) { //차트가 이미 존재한다면 지우고 다시 생성하기 위해서...
      line_chart.destroy();
    }

    var ctx1 = $('#line_chart')[0].getContext("2d");
    line_chart = new Chart(ctx1, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: '라인 차트',
          data: data,
          backgroundColor: color,
          borderColor: color,
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });


  },


  // 랜덤 색상 추출 함수
  getRandomColor: function (_isAlpha) {
    //알파 값이 true이면 투명한 값이 나올 수도 있음
    var r = getRand(0, 255),
      g = getRand(0, 255),
      b = getRand(0, 255),
      a = getRand(0, 10) / 10;

    var rgb = _isAlpha ? 'rgba' : 'rgb';
    rgb += '(' + r + ',' + g + ',' + b;
    rgb += _isAlpha ? ',' + a + ')' : ')';

    return rgb;

    // Return random number from in to max
    function getRand(min, max) {
      if (min >= max) return false;
      return ~~(Math.random() * (max - min + 1)) + min;
    };
  }

}//page