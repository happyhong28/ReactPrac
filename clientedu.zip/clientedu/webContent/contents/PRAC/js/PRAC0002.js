var page = {
  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {
      
    page.getLocation();

  },

  // 2. 사용자 인터렉션
  initInterface: function () {



  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {


  },

  //현재 위치에서 위도/경도 뽑기
  getLocation: function () {

    bizMOB.System.getGPS({
      "_fCallback" : function(res) {
          // alert(JSON.stringify(res.result));
          // console.log(res);

          if(res.result){
            page.callMap(res.latitude,res.longitude,res.address);


          }else{
            alert("지도를 불러오는 것을 실패했습니다.");


          }
      }
  });
  
  },

  callMap: function (lab, logi,address) {
    var mapOptions = {
      center: new naver.maps.LatLng(lab, logi),
      zoom: 16
    };
    var map = new naver.maps.Map('map', mapOptions);

    var marker = new naver.maps.Marker({
      position: new naver.maps.LatLng(lab, logi),
      title: '현재 위치',
      map: map
    });


    var str = [
      '<div style="padding:4px 4px;">',
      '<div style="font-weight:bold;padding-bottom:3px;">현재 위치정보</div>',
      '<p>위도: '+lab+'<p>',
      '<p>경도: '+logi+'<p>',
      '<p>주소: '+address+'<p>',
      '</div>'
    ].join('');

    var infowindow = new naver.maps.InfoWindow({
      content : str
    });

    naver.maps.Event.addListener(marker, "click", function (e) {
      if (infowindow.getMap()) {
        infowindow.close();
      } else {
        infowindow.open(map, marker);
      }
    });

    infowindow.open(map, marker);


  }



}//page