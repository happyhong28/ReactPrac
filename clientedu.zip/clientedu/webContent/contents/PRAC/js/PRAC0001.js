var page = {
  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {

  },

  // 2. 사용자 인터렉션
  initInterface: function () {

    // #1 지도
    $("#btn_map").click(function () {
      bizMOB.Window.open({
        "_sPagePath": "PRAC/html/PRAC0002.html",
        "_sType": "normal",
        "_oMessage": {
          "param": "Hello BizMOB"
        },
      });

    });


    // #2 swiper
    $("#btn_swiper").click(function () {
      bizMOB.Window.open({
        "_sPagePath": "PRAC/html/PRAC0003.html",
        "_sType": "normal",
        "_oMessage": {
          "param": "Hello BizMOB"
        },
      });
    });


    // #3 date picker
    $("#btn_datepicker").click(function () {
      bizMOB.Window.open({
        "_sPagePath": "PRAC/html/PRAC0004.html",
        "_sType": "normal",
        "_oMessage": {
          "param": "Hello BizMOB"
        },
      });
    });

    // #4 chart
    $("#btn_chart").click(function () {
      bizMOB.Window.open({
        "_sPagePath": "PRAC/html/PRAC0005.html",
        "_sType": "normal",
        "_oMessage": {
          "param": "Hello BizMOB"
        },
      });
    });

       // #5 chart2
       $("#btn_chart2").click(function () {
        bizMOB.Window.open({
          "_sPagePath": "PRAC/html/PRAC0006.html",
          "_sType": "normal",
          "_oMessage": {
            "param": "Hello BizMOB"
          },
        });
      });


  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {


  }
}//page