var mcnc_data = [{
  "FORM_TITLE": "10월 일반 경비 청구",
  "AMOUNT": "39,000",
  "POSITION": "매니저",
  "START_DATE": "20211002090000",
  "REG_NAME": "김정은9",
  "REG_ID": "1234567",
  "DEPT": "전략운영팀",
  "TEXT": [{
    "REG_DATA": "20210301100000",
    "REG_NAME": "이재성",
    "DEPT": "전략운영팀",
    "DESC": "결재 합니다."
  }, {
    "REG_DATA": "20210302123000",
    "REG_NAME": "홍길동",
    "DEPT": "전략운영팀",
    "DESC": "의견2222."
  }],
  "LIST": []
},

{
  "FORM_TITLE": "9월 일반 경비 청구",
  "AMOUNT": "39,000",
  "POSITION": "매니저",
  "START_DATE": "20210905100000",
  "REG_NAME": "김정은8",
  "REG_ID": "1234567",
  "DEPT": "전략운영팀",
  "TEXT": [{
    "REG_DATA": "20210301100000",
    "REG_NAME": "이재성",
    "DEPT": "전략운영팀",
    "DESC": "첨부파일 확인해 주세요"
  }],
  "LIST": [{
    "USE_DATE": "20210301",
    "USER_PLACE": "또와요짬뽕8",
    "USE_AMOUNT": "1,520,000"
  },
  {
    "USE_DATE": "20210908",
    "USER_PLACE": "미야기",
    "USE_AMOUNT": "32,200"
  },
  {
    "USE_DATE": "20210915",
    "USER_PLACE": "맥도날드",
    "USE_AMOUNT": "99,000"
  }
  ]
}, {
  "FORM_TITLE": "8월 일반 경비 청구",
  "AMOUNT": "59,000",
  "POSITION": "매니저",
  "START_DATE": "20210805100000",
  "REG_NAME": "김정은7",
  "REG_ID": "1234567",
  "DEPT": "전략운영팀",
  "TEXT": [],
  "LIST": [{
    "USE_DATE": "20210301",
    "USER_PLACE": "또와요짬뽕7",
    "USE_AMOUNT": "1,520,000"
  },
  {
    "USE_DATE": "20210908",
    "USER_PLACE": "미야기",
    "USE_AMOUNT": "32,200"
  }
  ]
}

]

var page = {
  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {
    page.getMCNCData();
  },

  // 2. 사용자 인터렉션
  initInterface: function () {

    // 결재정보 버튼 
    $("#list").on("click", ".btn_opin_view", function () {
      const $button = $(this);
      bizMOB.Window.open({
        "_sPagePath": "DOC/html/DOC0100.html",
        "_oMessage": {
          "textdata": $button.attr("textdata") //this 는 클릭된 element의 attr를 받기 위해서...
        }
      });
    });


    // 정렬 
    $(".btn_align").click(function () {

    // // 방법1. element를 정렬 
    // $(".btn_align").click(function () {

    //   // $(".case01 li").bMSort({
    //   //   "field": ".start_date",
    //   //   "orderby": "asc",
    //   //   "fieldType": "number"

    //   // });


    // 방법 2. 재 rendering
    if ($(".btn_align").attr("sorting") == "desc") {
      $(".btn_align").attr("sorting", "asc");

    }else if ($(".btn_align").attr("sorting") == "asc") {
      $(".btn_align").attr("sorting", "desc");

    }

    mcnc_data.bMSort({
      "keys": [
        { "orderby": $(".btn_align").attr("sorting"), "field": "START_DATE" }
      ]
    });

    page.renderList(mcnc_data);

  });




  },


  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {


  },

  getMCNCData: function () {

    // 에뮬레이터로 작동시
    if (bizMOB.Device.getInfo().model == "Emulator") {

      page.renderList(mcnc_data);
      // page.opinionList(mcnc_data);

    }
    // 핸드폰으로 작동시
    else {
      bizMOB.Push.getMessageList({

        "_sAppName": "bizMob3.5",
        "_nPageIndex": 1,
        "_nItemCount": 10,
        "_sUserId": "tester",
        "_fCallback": function (res) {
          if (res.result) {
            alert(JSON.stringify(res));
            page.renderList(res.body);
            // page.opinionList(res.body);
          }
        }
      });
    }


  },

  // 데이터뿌리기
  renderList: function (data) {
    $('.case01 li:gt(0)').remove();
    $(".count").html("총 <span>" + data.length + "건</span>");

    var dir = [
      {
        "type": "loop", "target": "li", "value": ".", "detail": [
          { "type": "single", "target": ".name", "value": "FORM_TITLE" },
          // { "type": "single", "target": ".start_date", "value": "START_DATE" },
          {
            "type": "single", "target": ".start_date", "value": function (arg) {
              var reg_data = arg.item.START_DATE.bMToFormatDate("yyyy.mm.dd (w) HH시nn분ss초");
              return reg_data;
            }
          },
          { "type": "single", "target": ".total", "value": "AMOUNT" },
          { "type": "single", "target": ".approval_id", "value": "REG_ID" },
          // { "type": "single", "target": ".approval_nm", "value": "REG_NAME" },
          { "type": "single", "target": ".depart_nm", "value": "DEPT" },

          {
            "type": "single", "target": ".btn_opin_view@textdata", "value": function (arg) {
              var context = arg.context;
              var index = arg.index;

              // console.log(context[index].TEXT);
              return JSON.stringify(context[index].TEXT)

            }
          },
          {
            "type": "single", "target": ".btn_opin_view", "value": function (arg) {

              // console.log(arg);
              if (Object.keys(arg.item.TEXT).length == 0) {
                $(arg.element).prop('disabled', 'true');
              } else {

              }
              return '결제의견 보기';
            }
          },
          {
            "type": "single", "target": ".tblWrap@class+", "value": function (arg) {
              if (Object.keys(arg.item.LIST).length == 0) {
                return ' hide';
              } else {
              }
            }
          },

          //또와요짬뽕 뜨는 부분
          {
            "type": "loop", "target": ".use_list", "value": "LIST", "detail": [
            
              { "type": "single", "target": ".use_date", "value": "USE_DATE" },
              { "type": "single", "target": ".use_place", "value": "USER_PLACE" },
              { "type": "single", "target": ".use_amount", "value": "USE_AMOUNT" }

            ]
          }

        ]
      }
    ];


    var options = { clone: true, newId: "list", replace: false };
    //클론 true면 clone하려는 sample date를 지우지 않는다는 의미
    //false일때는 완전히 sample data를 지우기 때문에
    //예를 들어, 7월에 대한 리스트를 보고 샘플데이터를 지우면
    //8월에 대한 리스트를 다시 렌더링할 때 그 샘플데이터가 없어서
    //렌더링 자체를 못하는 오류가 발생한다.
    //그러므로 이 경우에는 샘플데이터를 삭제하지 않고 
    //display를 false로 바꿔주는 방식으로 한다.
    $(".case01").bMRender(data, dir, options);

  }


}//page