var textdata = null;

var page = {

  // 0. 함수 실행
  init: function (param) {
    textdata = JSON.parse(param.data.textdata); // string -> json 형태로 다시 변환
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {
    console.log(textdata);
    page.renderList(textdata);
  },

  // 2. 사용자 인터렉션
  initInterface: function () {
    // 창닫기
    $("#btn_pop_close").click(function () {
      bizMOB.Window.close({
        "_oMessage": {
          "param": "Hello BizMOB!"
        },
        "_sCallback": "page.callback"
      });
    });


  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {

  },

  // 데이터뿌리기
  renderList: function (data) {
    console.log(data);
    console.log(data.length);
    $(".count").html("총 <span>" + data.length + "건</span>");

    var dir = [
      {
        "type": "loop", "target": "li", "value": ".", "detail": [
          { "type": "single", "target": ".reg_data", "value": function (arg) {
            var reg_data = arg.item.REG_DATA.bMToFormatDate("yyyy.mm.dd (w) HH시nn분ss초");
            return reg_data;
          }},
          { "type": "single", "target": ".reg_name", "value": "REG_NAME" },
          { "type": "single", "target": ".dept", "value": "DEPT" },
          { "type": "single", "target": ".desc", "value": "DESC" }
        ]
      }
    ];

    var options = { clone: false, newId: "list", replace: false };
    $(".opinList").bMRender(data, dir, options);

  }

}//page