var page = {
  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {
    page.reqList_alram();
    page.reqList_event();
    page.reqList_studydb();
    page.reqList_studygoods();


    // // 디테일
    // $("article").on("click", ".btn_detail", function () {

    // });




  },

  // 2. 사용자 인터렉션
  initInterface: function () {

    //전체 상품 보기
    $(".btn_more").click(function () {
      bizMOB.Window.open({
        "_sPagePath": "PDT/html/PDT0100.html",
        "_oMessage": {
          "blbr_id": "B02"
          // "ptup_no": ""
        }
      });
    });


  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {


  },


  // A 전문요청 : 알람
  reqList_alram: function () {
    bizMOB.Network.requestTr({
      "_sTrcode": "KM02030",
      "_oHeader": {
        "content_major_version": 999,
        "content_minor_version": 999,
        "app_key": "KUKWANP0",
        "display_type": "ALL",
        "deploy_type": "REAL",
        "is_crypt": false
      },
      "_oBody": {
        "user_id": ""

      },
      "_fCallback": function (res) {
        // console.log(res);
        if (res.body.newest_cnt == 0) { //새로운 알람이 없다면
          $(".btn_head_noti .new").remove();
        } else {//새로운 알람이 있다면

        }

      }
    });
  },

  // B 전문요청 : 이벤트 및 프로모션
  reqList_event: function () {
    bizMOB.Network.requestTr({
      "_sTrcode": "KM02010",
      "_oHeader": {
        "content_major_version": 999,
        "content_minor_version": 999,
        "app_key": "KUKWANP0",
        "display_type": "ALL",
        "deploy_type": "REAL",
        "is_crypt": false
      },
      "_oBody": {
        "blbr_id": "A01"
      },
      "_fCallback": function (res) {
        // console.log(res.body.blbr_list[0]);
        page.renderList_event(res.body.blbr_list);
      }
    });
  },

  // B-1 배너 띄워주는 함수
  renderList_event: function (data) {
    for (var i = 0; i < data.length; i++) {
      $(".swiper-wrapper").append(
        "<li class='swiper-slide'>" +
        "<div class='image'><img src='" + data[i].atch_file_url + "' alt='' /></div>" +
        "<button type='button' class='btn_detail'><span>Details</span></button></li>"
      ); //맨 앞에 추가
      // console.log(data[i].atch_file_url);

    }
    $(".swiper-wrapper .swiper-slide:eq(0)").attr("style", "display:none;");

    var banner_swiper = new Swiper(".swipe_banner", {
      slidesPerView: 1, //슬라이드를 한번에 3개를 보여준다
      spaceBetween: 0, //슬라이드간 padding 값 30px 씩 떨어뜨려줌
      loop: true, //loop 를 true 로 할경우 무한반복 슬라이드 false 로 할경우 슬라이드의 끝에서 더보여지지 않음
    });
  },

  // E 전문요청 : 학습자료실
  reqList_studydb: function () {
    bizMOB.Network.requestTr({
      "_sTrcode": "KM02010",
      "_oHeader": {
        "content_major_version": 999,
        "content_minor_version": 999,
        "app_key": "KUKWANP0",
        "display_type": "ALL",
        "deploy_type": "REAL",
        "is_crypt": false
      },
      "_oBody": {
        "blbr_id": "A07"
      },
      "_fCallback": function (res) {
        // console.log(res.body);
        page.renderList_studydb(res.body);
      }
    });
  },

  // E-1 학습자료실 띄워주는 함수
  renderList_studydb: function (data) {
    // console.log(data);
    var dir = [
      {
        "type": "loop", "target": ".template_li", "value": "blbr_list", "detail": [

          {
            "type": "single", "target": ".imgsrc@src", "value": function (arg) {
              // console.log(arg.item.atch_file_url);
              return arg.item.atch_file_url;
            }
          },
          { "type": "single", "target": ".imgspan", "value": "ntmt_nm" }
        ]
      }
    ];
    var options = { clone: true, newId: "li", replace: false };
    $(".template_ul").bMRender(data, dir, options); //ul 밑에 append 된다. data, dir, options 3개는 필수
    $(".template_ul .template_li:eq(0)").attr("style", "display:none;"); //샘플데이터 숨김
  },

  // H1 전문요청 : 학습상품
  reqList_studygoods: function () {
    bizMOB.Network.requestTr({
      "_sTrcode": "KM02020",
      "_oHeader": {
        "content_major_version": 999,
        "content_minor_version": 999,
        "app_key": "KUKWANP0",
        "display_type": "ALL",
        "deploy_type": "REAL",
        "is_crypt": false
      },
      "_oBody": {
        "blbr_id": "A08"
      },
      "_fCallback": function (res) {
        page.renderList_studygoods(res.body);
      }
    });
  },

  // H1-1 학습상품 띄워주는 함수
  renderList_studygoods: function (data) {
    console.log(data);
    var dir = [
      {
        "type": "loop", "target": ".subject_list_li", "value": "list", "detail": [

          {
            "type": "single", "target": ".subject_imagesrc@src", "value": function (arg) {
              return arg.item.atch_file_url;
            }
          },

          {
            "type": "single", "target": ".subject_title", "value": function (arg) {
              return arg.item.ntmt_nm;
            }
          },
          {
            "type": "single", "target": ".subject_age", "value": function (arg) {
              return arg.item.lnrg_prdt_rcmd_age;
            }
          },
          {
            "type": "single", "target": ".subject_type", "value": function (arg) {
              return arg.item.lnrg_prdt_div_txt;
            }
          },
          {
            "type": "loop", "target": ".optbox_container", "value": "detail_list", "detail": [
              {
                "type": "single", "target": ".optbox", "value": function (arg) {
                  // console.log(arg.item.detail_list);

                    if (arg.item.lrng_prdt_prom_cd == "001") {
                      return "S";
                    }
                    else if (arg.item.lrng_prdt_prom_cd == "002") {
                      return "P";
                    }
                    else if (arg.item.lrng_prdt_prom_cd == "003") {
                      return "K";
                    }
                    else if (arg.item.lrng_prdt_prom_cd == "004") {
                      return "B";
                    }
                  }






              },]
          },

          {
            "type": "single", "target": ".btn_detail@href", "value": function (arg) {
              return arg.item.link_url_1;
            }
          }
        ]
      }
    ];
    var options = { clone: true, newId: "li", replace: false };
    $(".subject_list").bMRender(data, dir, options); //ul 밑에 append 된다. data, dir, options 3개는 필수
    $(".subject_list .subject_list_li:eq(0)").attr("style", "display:none;"); //샘플데이터 숨김
  },

  // H2 전문요청 : 학습상품 컨텐츠 목록 조회
  reqList_getgoodslist: function () {
    bizMOB.Network.requestTr({
      "_sTrcode": "KM02010",
      "_oHeader": {
        "content_major_version": 999,
        "content_minor_version": 999,
        "app_key": "KUKWANP0",
        "display_type": "ALL",
        "deploy_type": "REAL",
        "is_crypt": false
      },
      "_oBody": {
        "blbr_id": "A08"
      },
      "_fCallback": function (res) {
        console.log(res);
        // return res;
        // console.log(res.body);
        // page.renderList_studygoods(res.body);

      }
    });
  }



















}//page