var page = {
  // 0. 함수 실행
  init: function (param) {
    console.log(param);
    page.initData(param.data.blbr_id);
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {


  },

  // 2. 사용자 인터렉션
  initInterface: function () {
    

  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {
   
     
  }
}//page