var page = {
    // 0. 함수 실행
    init: function (param) {

        page.initData(param.data);
        page.initInterface();
        page.initLayout();
    },

    // 1. 초기 데이터 관리
    initData: function (res) {
        page.getDetail(res);


    },

    // 2. 사용자 인터렉션
    initInterface: function () {


        // 창닫기
        $(".btn_head_prev").click(function () {
            console.log("닫기");
            bizMOB.Window.close({
                "_oMessage": {
                    "param": "Hello BizMOB!"
                },
                "_sCallback": "page.callback"
            });
        });

          //카카오톡으로 공유
        //   $(".btn_sns_kakao").click(function () {

        //     // var param = {
        //     //     "reqParam" : "paramString"
        //     // };
        //     var param = {
        //         // "callback": "",
        //         "title": "타이틀",
        //         "image_width": 300,
        //         "image_height": 500,
        //         "image_url": "../../common/images/@img_event_detail.png",
        //         "desc": "내용",
        //         "contents_link_type": "app",
        //         // "web_url": "",
        //         // "web_button": "",
        //         // "app_button": "앱에서 보기",
        //         // "app_param": {
        //         //     "callback": "onKakaoShare"
        //         // }
        //     }
        //     bizMOB.Util.callPlugIn("SHARE_KAKAO", param);
        // });




    },

    // 3. 레이아웃 타이틀바, 툴바, 사이드바
    initLayout: function () {


    },

    getDetail: function (res) {
        bizMOB.Network.requestTr({
            "_sTrcode": "KM01101",
            "_oHeader": {
                "content_major_version": 999,
                "content_minor_version": 999,
                "app_key": "KUKWANP0",
                "display_type": "ALL",
                "deploy_type": "REAL",
                "is_crypt": false
            },
            "_oBody": {
                "blbr_id": res.blbr_id, //게시판아이디(어차피 B01 고정)
                "ptup_no": res.ptup_no, //게시판번호

            },
            "_fCallback": function (res) {
                console.log(res.body);
                page.renderList(res.body);
               

                //카카오톡 공유하기
                $(".btn_sns_kakao").click(function () {

                    var param = {
                        // "callback": "",
                        "title": res.body.ntmt_nm, //타이틀
                        "image_width": 554,
                        "image_height": 270,
                        "image_url": res.body.atch_file_url,
                        "desc": "구몬앱 테스트", //내용
                        "contents_link_type": "app", //app 혹은 web
                        // "web_url": "https://www.naver.com/",
                        // "web_button": "웹에서 보기",
                        "app_button": "앱에서 보기", //버튼의 글씨
                        // "app_param": {
                        //     "callback": "onKakaoShare"
                        // }
                    }
                    bizMOB.Util.callPlugIn("SHARE_KAKAO", param);
                });
            }
        });
    },

    renderList: function (data) {


        var ntmt_perd_stt_dt1 = data.ntmt_perd_stt_dt.bMToFormatDate("yyyy.mm.dd");
        var ntmt_perd_end_dt1 = data.ntmt_perd_end_dt.bMToFormatDate("yyyy.mm.dd");
        var str = ntmt_perd_stt_dt1 + "~" + ntmt_perd_end_dt1;


        $(".tit strong").text(data.ntmt_nm); //타이틀
        $(".dateTodate").text(str); //기간
        // $(".image").attr("src", data.list[0].detail_atch_file_url);
        // console.log(data.list[0].detail_atch_file_url);
        // console.log(data.list.length);


        $(".image li:gt(0)").remove();
        for (var i = 0; i < data.list.length; i++) {
            // console.log(data.list[i].detail_atch_file_url);

            $(".board_detail").prepend('<div class="image"><img src="' + data.list[i].detail_atch_file_url + '" alt="이벤트 이미지" /></div>'); //맨 앞에 추가

        }

        $("#default_img").remove();
    },


    //카카오톡으로 공유
    share_kakao: function () {

    }


};//page