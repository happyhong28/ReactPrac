var page = {
  // 0. 함수 실행
  init: function () {
    console.log();
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {
    page.reqList_all();


  },

  // 2. 사용자 인터렉션
  initInterface: function () {
    $("#tab_all").click(function () {
      page.reqList_all();
    });

    $("#tab_ing").click(function () {
      page.reqList_ing();
    });

    $("#tab_finish").click(function () {
      page.reqList_finish();
    });


    $("body").on("click", ".li_no", function () {
      console.log("click");
      console.log($(this).attr("value"));
      bizMOB.Window.open({
        "_sPagePath": "BNF/html/BNF0101.html",
        "_oMessage": {
          "blbr_id": "B01",
          "ptup_no": $(this).attr("value") //this 는 클릭된 element의 attr를 받기 위해서...
        }
      });

    });



  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {


  },

  reqList_all: function () {
    bizMOB.Network.requestTr({
      "_sTrcode": "KM01100",
      "_oHeader": {
        "content_major_version": 999,
        "content_minor_version": 999,
        "app_key": "KUKWANP0",
        "display_type": "ALL",
        "deploy_type": "REAL",
        "is_crypt": false
      },
      "_oBody": {
        "list_blbr_id": "B01",
        "list_end_no": "",
        "list_gubun": "A", //전체
        "list_sttd_no": ""
      },
      "_fCallback": function (res) {
        // $(".benefit_list li:gt(0)").remove();
        page.renderList(res.body);

      }
    });
  },

  reqList_ing: function () {
    bizMOB.Network.requestTr({
      "_sTrcode": "KM01100",
      "_oHeader": {
        "content_major_version": 999,
        "content_minor_version": 999,
        "app_key": "KUKWANP0",
        "display_type": "ALL",
        "deploy_type": "REAL",
        "is_crypt": false
      },
      "_oBody": {
        "list_blbr_id": "B01",
        "list_end_no": "",
        "list_gubun": "Y", //진행중
        "list_sttd_no": ""
      },
      "_fCallback": function (res) {
        // $(".benefit_list li:gt(0)").remove();
        page.renderList(res.body);

      }
    });
  },

  reqList_finish: function () {
    bizMOB.Network.requestTr({
      "_sTrcode": "KM01100",
      "_oHeader": {
        "content_major_version": 999,
        "content_minor_version": 999,
        "app_key": "KUKWANP0",
        "display_type": "ALL",
        "deploy_type": "REAL",
        "is_crypt": false
      },
      "_oBody": {
        "list_blbr_id": "B01",
        "list_end_no": "",
        "list_gubun": "N", //종료
        "list_sttd_no": ""
      },
      "_fCallback": function (res) {
        // $(".benefit_list li:gt(0)").remove();
        page.renderList(res.body);

      }
    });
  },

  renderList: function (data) {

    $(".benefit_list li:gt(0)").remove();
    // 첫번째 li태그를 제외하고 모두 삭제하고 시작
    // li 태그들이 무한정으로 계속 쌓이는 것을 방지하기 위해

    var dir = [
      {
        "type": "loop", "target": "li", "value": "list", "detail": [
          { "type": "single", "target": ".@value", "value": "ptup_no" }, //맨 위 li 태그에 아예 게시글번호를 삽입
          { "type": "single", "target": ".img_link@src", "value": "atch_file_url" },
          { "type": "single", "target": ".tit", "value": "ntmt_nm" },
          // { "type": "single", "target": ".type", "value": "status" },

          { "type" : "single", "target" : ".txtbox_status", "value" : function(arg){ 
              //this가 list를 바라보는 이유? element가 찍혀야하는거아닌가? ---> Q
               console.log($(this));
              console.log(arg);

              
              if(arg.item.status == "01"){ //정상
                console.log(arg.item.status);
                return "진행중";

              }else if(arg.item.status == "02"){ //기한종료
                console.log(arg.item.status);
                return "종료";
              }


          }},

          //이부분 중요! 다시보기
          { "type" : "single", "target" : ".txtbox_status@class+", "value" : function(arg){ 
            
            if(arg.item.status == "01"){ //정상
              return "";

            }else if(arg.item.status == "02"){ //기한종료
              return " end";
            }


        }},

          {
            "type": "single", "target": ".date", "value": function (arg) {
              // console.log(arg.item.ntmt_perd_stt_dt);
              var ntmt_perd_stt_dt1 = arg.item.ntmt_perd_stt_dt.bMToFormatDate("yyyy.mm.dd");
              var ntmt_perd_end_dt1 = arg.item.ntmt_perd_end_dt.bMToFormatDate("yyyy.mm.dd");
              var str = ntmt_perd_stt_dt1 + "~" + ntmt_perd_end_dt1;
              //  console.log(ntmt_perd_stt_dt1);
              return str;
            }
          }

        ]
      }
    ];

    var options = { clone: true, newId: "list", replace: false };
    $(".benefit_list").bMRender(data, dir, options); //ul 밑에 append 된다. data, dir, options 3개는 필수
    $(".benefit_list:eq(0)").attr("style", "display:none;"); //샘플데이터 숨김
  }
};//page