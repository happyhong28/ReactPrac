bizMOB.addEvent("beforeready", "page.before");

var page = {

  $temp: undefined,
  $table : undefined,

  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {
    page.getNotiList();

  },

  // 2. 사용자 인터렉션
  initInterface: function () {


  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {
    util.setBackTitle("알림함");


  },


  // 푸시메세지를 담는 리스트
  getNotiList: function () {

    // 에뮬레이터로 작동시
    if (bizMOB.Device.getInfo().model == "Emulator") {
      var data = {
        "totalCount": "7",
        "items": [
          {
            "messageSubject": "testsubject",
            "messageContent": "testcontent",
            "fromUser": "testadmin",
            "trxDay": "20200907"
          }
        ]
      }

      var stu_data = [{
        "stuCd": "1111",
        "stuNm": "홍길동#",
        "subjList": [{
          "subjNm": "수학",
          "subjCd": "1"
        },
        {
          "subjNm": "영어1",
          "subjCd": "2"
        }, {
          "subjNm": "과학",
          "subjCd": "3"
        }
        ]
      },
      {
        "stuCd": "2222",
        "stuNm": "박길동#",
        "subjList": [{
          "subjNm": "영어1",
          "subjCd": "2"
        }, {
          "subjNm": "과학",
          "subjCd": "3"
        }]
      },
      {
        "stuCd": "3333",
        "stuNm": "이길동#",
        "subjList": [{
          "subjNm": "과학1",
          "subjCd": "3"
        }]
      }
      ]
      page.renderList(data);
      page.renderTable(stu_data);
    }
    // 핸드폰으로 작동시
    else {
      bizMOB.Push.getMessageList({
        "_sAppName": "bizMob3.5",
        "_nPageIndex": 1,
        "_nItemCount": 10,
        "_sUserId": "tester",
        "_fCallback": function (res) {
          //alert(JSON.stringify(res));
          if (res.result) {
            alert(JSON.stringify(res));
            page.renderList(res.body);
            // page.renderTable();
          }
        }
      });
    }
  },

  renderList: function (data) {
    console.log(data);

    $("#totalCnt").text(data.totalCount);

    // for (var i = 0; i < data.items.length; i++) {
    //   var item = data.items[i];
    //   var $li = page.$temp.clone();

    //   $li.find(".title").text(item.messageSubject);
    //   $li.find(".content").text(item.messageContent);
    //   $li.find(".sendUser").text(item.messagefromUser);
    //   $li.find(".sendDate").text(item.messagetrxDay.bMToFormatDate("yyyy-mm-dd"));

    //   $li.appendTo("ul");
    // }

    //
    var dir = [
      {
        "type": "loop", "target": "li", "value": "items", "detail": [ //loop라고 적어주면 알아서 순서를 읽어옴 0,1,2 ...
          // value에 .만 찍으면 상위 내용을 가져온다.
          // 각 row를 읽어온다음 그 안의 value값을 한개씩 가져온다.
          { "type": "single", "target": ".title", "value": "messageSubject" },
          { "type": "single", "target": ".content", "value": "messageContent" },
          { "type": "single", "target": ".sendUser", "value": "fromUser" },
          {
            "type": "single", "target": ".sendDate", "value": function (arg) {
              var regDate = arg.item.trxDay;
              return regDate.bMToFormatDate("yyyy.mm.dd");
            }
          }
          // { "type" : "single", "target" : ".sendDate", "value" : "messagetrxDay" }

        ]
      }
    ];

    var options = { clone: true, newId: "list", replace: false };

    $("#listT").bMRender(data, dir, options);

  },


  renderTable: function (data) {
    console.log(data);

    var dir = [
      {
        "type": "loop", "target": "tr", "value": ".", "detail": [ //loop라고 적어주면 알아서 순서를 읽어옴 0,1,2 ...
          // value에 .만 찍으면 상위 내용을 가져온다.
          // 각 row를 읽어온다음 그 안의 value값을 한개씩 가져온다.
          { "type": "single", "target": ".stuCd", "value": "stuCd" },
          { "type": "single", "target": ".stuNm", "value": "stuNm" },
          { "type": "loop", "target": ".subjNm", "value": "subjList", "detail": [
            { "type": "single", "target": ".", "value": "subjNm" }
          ]}
          // { "type": "loop", "target": ".subjList", "value": "subjList", "detail": function(arg){ 
          //   // console.log(arg.item.regDate);
          //    return arg.subjNm;
          
          // }
        


        ]
      }
    ];

    var options = { clone: true, newId: "tr", replace: false };

    $(".tbodyT").bMRender(data, dir, options);


  },

  // 리스트를 템플릿으로 화면에 뿌려주기
  before: function () {
    page.$temp = $("li").clone();
    //$("li").remove();
    //page.$table = $("trT").clone();
  }

}//page