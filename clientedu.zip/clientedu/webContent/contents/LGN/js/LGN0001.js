function onSessionTimeout() {
  //일정시간동안 터치가 없으면 앱종료시키는 함수
  bizMOB.App.exit({
    "_sType": "kill"
  });
}

// bizMOB.addEvent("resume", "page.resume");
// bizMOB.addEvent("open", "page.callbackOpen");
// bizMOB.addEvent("ready", "page.callbackReady");
// bizMOB.addEvent("beforeready", "page.callbackBeforeReady");

var page = {

  // 0. 함수 실행
  init: function (param) {

    //console.log("param >> ", param)
    page.initData(param.data);
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {
   

  },

  // 2. 사용자 인터렉션
  initInterface: function () {


    // TextButton이라는 요소 생성해서 변수에 담아준다.
    $("#btnAppExit").click(function () {
      var btn1 = bizMOB.Window.createElement({
        "_sElementName": "TextButton"
      });

      var btn2 = bizMOB.Window.createElement({
        "_sElementName": "TextButton"
      });

      // 버튼에 속성 추가
      btn1.setProperty({
        "_sText": "확인",
        "_fCallback": function () {
          bizMOB.App.exit({
            "_sType": "kill"
          });
        }
      });

      btn2.setProperty({
        "_sText": "취소",
        "_fCallback": function () {
          // bizMOB.App.exit({
          //   "_sType": "kill"
          // });
        }
      });

      bizMOB.Window.confirm({
        "_sTitle": "종료?",
        "_vMessage": "정말로 종료하시겠습니까?",
        "_aTextButton": [btn1, btn2]
      });


    });


    // 로그인
    $("#btnLogin").click(function () {
      var userId = $("#empId").val();
      var userPw = $("#empPw").val();


      // 입력된 아이디 값을 보내준다.
      bizMOB.Properties.set({
        "_sKey": "userId",
        "_vValue": userId
      });

      bizMOB.Network.requestLogin({
        "_sUserId": userId,
        "_sPassword": userPw,
        "_sTrcode": "DM0001", //전문코드
        // "_oHeader" : header,
        "_oBody": {
          "userId": userId,
          "userPw": userPw
        },
        "_fCallback": function (res) {
          bizMOB.Properties.set({
            //입력된 아이디값을 name이라는 키값에 저장한다.

            "_sKey": "name",
            "_vValue": res.body.userName
          });
          console.log(res);

          if (res.header.result) { //로그인 성공
            // 푸시키 받기
            bizMOB.Push.getPushKey({
              "_fCallback": function (res) {
                // alert(JSON.stringify(res));
                if (res.result) {
                  bizMOB.Push.registerToServer({
                    "_sServerType": "bizpush",
                    "_sUserId": userId, //empId
                    "_sAppName": "bizMob3.5",
                    "_fCallback": function (regRes) {
                      alert(JSON.stringify(regRes));
                    }
                  });
                }
              }
            });

            bizMOB.Window.open({
              "_sPagePath": "MAI/html/MAI0002.html",
              "_oMessage": {
                "userName": res.body.userName
              }
            });

          } else { //로그인 실패
            bizMOB.Window.alert({
              "_sTitle": "로그인 실패",
              "_vMessage": res.header.error_text,

            });
          }
        }
      });

    });


    // 회원가입
    $("#btnJoin").click(function () {

      bizMOB.Window.open({
        "_sPagePath": "LGN/html/LGN0003.html",
        "_oMessage": {


        }
      });
    });


    // QR리더
    $("#btnCodeReader").click(function () {
      bizMOB.Window.openCodeReader({
        "_fCallback": function (res) {
          //alert(JSON.stringify(res));
          if (res.result) {
            var url = bizMOB.Device.isAndroid() ? res.data : res.data.result_value;
            bizMOB.System.callBrowser({ //
              "_sURL": url
            });
          }
        }
      });
    });

    // 카메라
    $("#btnCamera").click(function () {
      bizMOB.System.callCamera({
        "_sFileName": "capture.jpg",
        "_sDirectory": "{external}/bizMOB/",
        "_bAutoVerticalHorizontal": true,
        "_fCallback": function (res) {
          // alert(JSON.stringify(res));
          var path = res.path;
          bizMOB.File.upload({
            "_aFileList": [
              {
                "_sSourcePath": path,
                "_sFileName": path.substr(path.lastIndexOf("/") + 1)
              }],
          });
          return;
          bizMOB.Window.openImageViewer({
            "_sImagePath": res.path
          });

        }
      });
    });


    // 서명
    $("#btnSign").click(function () {
      bizMOB.Window.openSignPad({
        "_sTargetPath": "{temporary}/sign.bmp",
        "_fCallback": function (res) {
          //alert(JSON.stringify(res));
          if (res.result) {
            $("#signImg").attr("src", "data:image/bml;base64," + res.sign_data);
          }


        }
      });
    });

    // 팝업창 띄우기
    $("#btnPut").click(function () {
      bizMOB.Window.open({
        "_sPagePath": "MAI/html/MAI0001.html",
        "_sType": "popup",
        "_sWidth": "50%",
        "_sHeight": "50%",
        "_oMessage": {
          "param": "Hello BizMOB"
        }
      });
    });

    // 메인창에서 과제창
    $("#btn_hw").click(function () {
      bizMOB.Window.open({
        "_sPagePath": "DOC/html/DOC0001.html",
        "_sType": "normal",
        "_sWidth": "50%",
        "_sHeight": "50%",
        "_oMessage": {
          "param": "Hello BizMOB"
        }
      });

    });

    //전화걸기
    $("#btnCall").click(function () {
      bizMOB.System.callTEL({
        "_sNumber": "01062616328",
        "_fCallback": function (res) {
          alert(JSON.stringify(res));
        }
      });
    });

    //문자보내기
    $("#btnText").click(function () {
      bizMOB.System.callSMS({
        "_aNumber": ["01062616328"],
        "_sMessage": "테스트 메세지입니다.",
        "_fCallback": function (res) {
          alert(JSON.stringify(res));
        }
      });
    });

    //다운로드
    $("#btnDownload").click(function () {

      var fileList = [
        {
          _sURI: "http://bizmob.mobilecnc.com/square/images/diagram_1.png",
          _bOverwrite: true,
          _sFileName: "downImg.png",
          _sDirectory: "{external}/clientEdu/"
        }
      ];

      bizMOB.File.download({
        "_aFileList": fileList,
        "_sMode": "foreground", // background
        "_sProgressBar": "full",// off , each, full
        "_fCallback": function (res) {
          if (res.result) {
            bizMOB.Window.alert({
              _sTitle: "알림",
              _vMessage: res
              // _vMessage : "총" + res.total_count + "개 중 " + res.current_count + "개 파일의 다운로드를 성공하였습니다."
            });
            // alert(JSON.stringify(res));
          } else {
            bizMOB.Window.alert({
              _sTitle: "알림",
              _vMessage: "파일 다운로드를 실패하였습니다."
            });
          }
        }

      });
    });


    //파일존재여부
    $("#btnFileExist").click(function () {
      bizMOB.File.exist({
        "_sSourcePath": "{external}/clientEdu/downImg.png",
        "_fCallback": function (res) {
          if (res.result) {

            bizMOB.File.getInfo({
              "_aFileList": [{ "_sSourcePath": "{external}/clientEdu/downImg.png" }],
              "_fCallback": function (fileInfo) {
                // alert(JSON.stringify(res));
                bizMOB.Window.alert({
                  _sTitle: "알림",
                  _vMessage: JSON.stringify(fileInfo)
                });
              }
            });

            // bizMOB.Window.alert({
            //   _sTitle: "알림",
            //   _vMessage: "파일이 존재합니다."
            // });

          } else {
            bizMOB.Window.alert({
              _sTitle: "알림",
              _vMessage: "파일이 존재하지 않습니다."
            });
          }
        }
      });
    });


    //파일복사
    $("#btnFileCopy").click(function () {

      bizMOB.File.copy({
        "_sSourcePath": "{external}/clientEdu/downImg.png",
        "_sTargetPath": "{external}/clientEdu/downImg_copy.png",
        "_fCallback": function (res) {
          if (res.result) {
            bizMOB.Window.alert({
              _sTitle: "알림",
              _vMessage: res
            });
          } else {
            bizMOB.Window.alert({
              _sTitle: "알림",
              _vMessage: "복사를 실패하였습니다."
            });
          }
        }
      });

    });

    //파일이동
    $("#btnFileMove").click(function () {
      bizMOB.File.move({
        "_sSourcePath": "{external}/clientEdu/downImg.png",
        "_sTargetPath": "{external}/clientEdu2/downImg.png",
        "_fCallback": function (res) {
          if (res.result) {
            bizMOB.Window.alert({
              _sTitle: "알림",
              _vMessage: res
            });
          } else {
            bizMOB.Window.alert({
              _sTitle: "알림",
              _vMessage: "파일 이동을 실패하였습니다."
            });
          }
        }
      });

    });

    //파일삭제
    $("#btnFileRemove").click(function () {
      bizMOB.File.remove({
        "_aSourcePath": "{external}/clientEdu/downImg_copy.png",
        "_fCallback": function (res) {
          if (res.result) {
            alert(JSON.stringify(res));
          } else {
            bizMOB.Window.alert({
              _sTitle: "알림",
              _vMessage: "파일 삭제를 실패하였습니다."
            });
          }


        }
      });

    });

  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {

    //초기 세팅
    util.setBackTitle("로그인");
    util.setToolBar();

    //blue
    $("#btn_blue").click(function () {
      util.setThemeChange("로그인", "");

    });

    //green
    $("#btn_green").click(function () {
      util.setThemeChange("로그인", "_green");

    });

    //orange
    $("#btn_orange").click(function () {
      util.setThemeChange("로그인", "_orange");

    });

    //pink
    $("#btn_pink").click(function () {
      util.setThemeChange("로그인", "_pink");

    });



  },

  drawImg: function (res) {


    var path = res.path;
    bizMOB.File.upload({
      "_aFileList": [
        {
          "_sSourcePath": path,
          "_sFileName": path.substr(path.lastIndexOf("/") + 1)
        }],
    });

    //return;


    bizMOB.File.getInfo({
      "_aFileList": [{ "_sSourcePath": res.list[0].target_path }],
      "_fCallback": function (res) {
        // alert(JSON.stringify(res));
        bizMOB.Window.alert({
          _sTitle: "resize 전",
          _vMessage: JSON.stringify(res)
        });
      }
    });

    bizMOB.File.resizeImage({
      "_aFileList": [{
        "_sSourcePath": res.list[0].target_path
      }],

      "_bIsCopy": false,
      "_sTargetDirectory": "{external}/clientEdu",
      "_nCompressRate": 0.5,
      "_fCallback": function (res) {
        // 팝업 페이지 닫기
        // alert(JSON.stringify(res))

        if (res.result) {

          var path = res.list[0].target_path;
          bizMOB.File.upload({
            "_aFileList": [
              {
                "_sSourcePath": path,
                "_sFileName": path.substr(path.lastIndexOf("/") + 1)
              }],
          });
        }


        bizMOB.File.getInfo({
          "_aFileList": [{ "_sSourcePath": res.path }],
          "_fCallback": function (res) {
            alert(JSON.stringify(res));

            bizMOB.Window.alert({
              _sTitle: "resize 후",
              _vMessage: JSON.stringify(res.path)
            });
          }
        });

      }
    });

    // parameter 이름이 path인것을 찾는 것..
    $("#putDiv").append("<img src=" + res.path + "></img>");
  }
}//page