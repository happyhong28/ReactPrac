var page = {
  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {


  },

  // 2. 사용자 인터렉션
  initInterface: function () {

    $("#form").bMValidate(
      {
        "rules":
        {
          // "#userId": "required::아이디를 입력해주세요.",
          "#userId": "minLength(7)::아이디 최소 7자리 이상",
          // "#userPw": "required::비밀번호를 입력해주세요.",
          "#userPw": "minLength(10)::비밀번호 최소 10자리 이상",
          // "#userEmail": "email::이메일 형식을 입력해주세요.",
          "#userEmail": function (target, rule) {
            if (target.val() == "") { //아무것도 입력하지 않으면 검사를 하지 않는다.
              return true;
            } else {
              if (rule.email(target) === false) {
                return "이메일 형식을 확인해주세요";
              } else {
                return true;
              }
            }
          },
          // "#userBirth": "date::날짜 형식을 입력해주세요.",
          "#userBirth": function (target, rule) {
            if (target.val() == "") { //아무것도 입력하지 않으면 검사를 하지 않는다.
              return true;
            } else {
              if (rule.date(target) === false) {
                return "날짜 형식을 입력해주세요";
              } else {
                return true;
              }
            }
          },
          "#userPath": "in('지인소개','인터넷','SNS')::지인소개/인터넷/SNS 중에서만 입력가능합니다."
        }
      });

    $("#btnJoin").click(function () {
      $("#form").bMValidate("check");

      console.log($("#form").bMValidate("check"));
      if ($("#form").bMValidate("check")) {
        alert("회원가입 완료 (임시)");
      }

    });


  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {
    util.setBackTitle("회원가입");

  }
}//page