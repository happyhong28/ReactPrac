(function () {
  var util = {};
  window.util = util;
  var TITLE_BG_PATH = "app/images/skin_blue/titleBar/";
  var BTN_BG_PATH = "app/images/btn/";
  var TOOL_BAR_PATH = "app/images/toolbar/phone/";

  // 1. 타이틀바 (백버튼)
  util.setBackTitle = function (title) {

    var titleBar = bizMOB.Window.createTitleBar({
      "_sTitle": title
    });

    var backBtn = bizMOB.Window.createElement({
      "_sElementName": "ImageButton"
    });

    titleBar.setProperty({
      "_sImagePath": TITLE_BG_PATH + "titleBg.png",
      "_aLeftImageButton": [backBtn]

    });

    backBtn.setProperty({
      "_sImagePath": BTN_BG_PATH + "btnBack.png",
      "_fCallback": function () {
        bizMOB.Window.close();
      }

    });

    bizMOB.Window.draw({
      "_aElement": [titleBar, backBtn]
    });

  }

  // 2. 타이틀바 (사이드뷰)
  util.setMenuTitle = function (title) {
    var titleBar = bizMOB.Window.createTitleBar({
      "_sTitle": title
    });

    var menuBtn = bizMOB.Window.createElement({
      "_sElementName": "ImageButton"
    });

    menuBtn.setProperty({
      "_sImagePath": BTN_BG_PATH + "btn_menu.png",
      "_fCallback": function () {
        bizMOB.SideView.show({
          "_sPosition": "left"
        });
        // bizMOB.Window.close();
      }

    });

    titleBar.setProperty({
      "_sImagePath": TITLE_BG_PATH + "titleBg.png",
      "_aLeftImageButton": [menuBtn]

    });

    bizMOB.Window.draw({
      "_aElement": [titleBar]
    });

  }

  // 3. 테마 바꾸기
  util.setThemeChange = function (title, color) {

    var titleBar = bizMOB.Window.createTitleBar({
      "_sTitle": title
    });

    var backBtn = bizMOB.Window.createElement({
      "_sElementName": "ImageButton",
      "_fCallback": function () {
        bizMOB.Window.close();
      }
    });


    titleBar.setProperty({
      "_sImagePath": TITLE_BG_PATH + "titleBg" + color + ".png",
      "_aLeftImageButton": [backBtn]
    });

    backBtn.setProperty({
      "_sImagePath": BTN_BG_PATH + "btnBack.png"

    });

    bizMOB.Window.draw({
      "_aElement": [titleBar, backBtn]
    });
  }

  // 4. 툴바
  util.setToolBar = function () {

    var toolbar1 = bizMOB.Window.createElement({
      "_sElementName": "ImageButton"
    });

    toolbar1.setProperty({
      "_sImagePath": TOOL_BAR_PATH + "AC01.png",
      "_fCallback": function () {
      }
    });

    var toolbar2 = bizMOB.Window.createElement({
      "_sElementName": "ImageButton"
    });

    toolbar2.setProperty({
      "_sImagePath": TOOL_BAR_PATH + "AC02.png",
      "_fCallback": function () {
      }
    });

    var toolbar3 = bizMOB.Window.createElement({
      "_sElementName": "ImageButton"
    });

    toolbar3.setProperty({
      "_sImagePath": TOOL_BAR_PATH + "AC03.png",
      "_fCallback": function () {
      }
    });


    var toolbar4 = bizMOB.Window.createElement({
      "_sElementName": "ImageButton"
    });

    toolbar4.setProperty({
      "_sImagePath": TOOL_BAR_PATH + "AC04.png",
      "_fCallback": function () {
      }
    });

    var toolbar5 = bizMOB.Window.createElement({
      "_sElementName": "ImageButton"
    });

    toolbar5.setProperty({
      "_sImagePath": TOOL_BAR_PATH + "BB01.png",
      "_fCallback": function () {
      }
    });


    var toolBar = bizMOB.Window.createToolBar();

    toolBar.setProperty({
      "_aImageButton": [toolbar1, toolbar2, toolbar3, toolbar4, toolbar5],
      "_sImagePath": TOOL_BAR_PATH + "bg_phone_ios",
      "_sID": "bottomToolBar"
    });

    bizMOB.Window.draw({
      "_aElement": [toolBar]
    });
  }

  // 5. 사이드뷰에서 메뉴 선택 (게시판, 알림함, 설정)
  util.callbackMenu = function (param) {
     console.log(param);
    var path = param.data.path;
    // var test = param.data.test; 

    if (path) {
      bizMOB.Window.open({
        "_sPagePath": path
      });
    }
  };

})(); //함수를 선언과 동시에 선언



