// # 사이드뷰 화면 #

// 이 창이 실행될 때 util에 있는 callbackMenu 함수를 실행시켜라
// 이때 callbackMenu 함수는 각 메뉴에 맞는 창을 여는 코드를 포함하고 있음...
bizMOB.addEvent("close", "util.callbackMenu");

var page = {

  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {


  },

  // 2. 사용자 인터렉션
  initInterface: function () {

    // 사이드뷰 닫기
    $("#btnClose").click(function () {
      bizMOB.SideView.hide();

    });

    // 게시판, 알림함, 설정을 눌렀을 때 해당하는 화면으로 이동
    $("li").click(function () {
      bizMOB.SideView.hide({
        "_oMessage": { 
          //여기에 쓰는 부분을 callbackMenu 함수가 받아서 쓰게된다.
          //맨 위에서 사이드뷰가 hide 될 때 callbackMenu 함수가 실행되게 했으므로... 
          "path": $(this).attr("path"),
          // "test":"test param"
        }
      });
    });

  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {




  }
}//page