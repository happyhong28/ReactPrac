// # 메인입니다. 화면 #

var page = {

  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {

  var userName = bizMOB.Properties.get({
      "_sKey" : "name"
  });
  $("#name").text(userName);


  },

  // 2. 사용자 인터렉션
  initInterface: function () {

    
  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {

   // app.config 파일에 대신 써줄수도 있음
    bizMOB.SideView.create({
      "_sPosition" : "left",  // or right
      "_sPagePath" : "MAI/html/MAI0003.html",
      "_sWidth" : "70"
  });

    //사이드뷰 열기
    util.setMenuTitle("메인");

    




  }
}//page