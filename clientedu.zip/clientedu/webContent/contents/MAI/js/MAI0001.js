// # 팝업창 화면 #

var page = {
  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {


  },

  // 2. 사용자 인터렉션
  initInterface: function () {
    // 카메라
    $("#btnPutimg").click(function () {
      bizMOB.System.callCamera({
        "_sFileName": "capture.jpg",
        "_sDirectory": "{external}/bizMOB/",
        "_bAutoVerticalHorizontal": true,
        "_fCallback": function (res) {

          // if (res.path) {
          //   var $img = $("<img>").attr("src", res.path);
          //   $("#putDiv").append($img);

          // }
          bizMOB.Window.close({
            "_oMessage": {
              "path": res
            },
            "_sType": "popup",
            "_sCallback": "page.drawImg"
          });
        }
      });

    });

    // 갤러리
    $("#btnGogallary").click(function () {
      bizMOB.System.callGallery({
        "_sType": "image",
        "_fCallback": function (res) {
           // 팝업 페이지 닫기
              bizMOB.Window.close({
                "_oMessage": {
                  "path": res.images[0].uri
                },
                "_sType": "popup",
                "_sCallback": "page.drawImg"
              });

          // bizMOB.File.getInfo({
          //   "_aFileList": [{ "_sSourcePath": res.images[0].uri }],
          //   "_fCallback": function (res) {
          //     // alert(JSON.stringify(res));
          //     bizMOB.Window.alert({
          //       _sTitle: "resize 전",
          //       _vMessage: JSON.stringify(res)
          //     });
          //   }
          // });

          // bizMOB.File.resizeImage({
          //   "_aFileList": [{
          //     "_sSourcePath": res.images[0].uri
          //   }],

          //   "_bIsCopy": true,
          //   "_sTargetDirectory": "{external}/clientEdu",
          //   "_nWidth": 800,
          //   "_nHeight": 600,
          //   "_nCompressRate": 0.8,
          //   "_nFileSize": 1000000,
          //   "_fCallback": function (res) {

          //     bizMOB.File.getInfo({
          //       "_aFileList": [{ "_sSourcePath": res.images[0].uri }],
          //       "_fCallback": function (res) {
          //         // alert(JSON.stringify(res));
          //         bizMOB.Window.alert({
          //           _sTitle: "resize 후",
          //           _vMessage: JSON.stringify(res)
          //         });
          //       }
          //     });

          //     // 팝업 페이지 닫기
          //     bizMOB.Window.close({
          //       "_oMessage": {
          //         "path": res.images[0].uri
          //       },
          //       "_sType": "popup",
          //       "_sCallback": "page.drawImg"
          //     });

          //   }
          // });

          // // 팝업 페이지 닫기 
          // bizMOB.Window.close({
          //   "_oMessage": {
          //     "path": res.images[0].uri
          //   },
          //   "_sType": "popup",
          //   "_sCallback": "page.drawImg"
          // });
        }
      });

    });


    // 취소
    $("#btnCancle").click(function () {

      // 팝업 페이지 닫기
      bizMOB.Window.close({
        "_oMessage": {
          "param": "Hello BizMOB!"
        },
        "_sType": "popup",
        "_sCallback": "page.callback"
      });


    });


  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {
    util.setBackTitle("로그인");

    var imageButton = bizMOB.Window.createElement({
      "_sElementName": "ImageButton"
    });
    imageButton.setProperty({
      "_sImagePath": "common/images/btn_del.png",
      "_fCallback": function () {
        bizMOB.Window.alert({
          "_sTitle": "알림",
          "_vMessage": "이미지 버튼을 클릭했습니다."
        });
      }
    });

  }
}//page


