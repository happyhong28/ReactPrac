var page = {
  // 0. 함수 실행
  init: function () {
    page.initData();
    page.initInterface();
    page.initLayout();
  },

  // 1. 초기 데이터 관리
  initData: function () {


  },

  // 2. 사용자 인터렉션


  initInterface: function () {

    // 로그인 창에 입력된 아이디 받아온다.
    var userId = bizMOB.Properties.get({
      "_sKey": "userId"
    });


    // 알림설정
    $("#setAlram").click(function () {
      var getOnoff = $('input[name="radio"]:checked').val();
      // console.log(getOnoff);

      if (getOnoff == "on") {
        bizMOB.Push.setAlarm({
          "_sUserId": userId,
          "_bEnabled": true,
          "_fCallback": function (res) {
            alert(JSON.stringify(res));
            // alert(userId+" | "+getOnoff);
            // console.log(JSON.stringify(res));
          }
        });
      } else if (getOnoff == "off") {
        bizMOB.Push.setAlarm({
          "_sUserId": userId,
          "_bEnabled": false,
          "_fCallback": function (res) {
            alert(JSON.stringify(res));
            // alert(userId+" | "+getOnoff);
            // console.log(JSON.stringify(res));
          }
        });


      }

    });


  },

  // 3. 레이아웃 타이틀바, 툴바, 사이드바
  initLayout: function () {
    util.setBackTitle("알림설정");


  },


}//page